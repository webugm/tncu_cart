module.exports = {

	"env": {
		"browser": true,
		"jquery": true
	},

  "parserOptions": {
		"ecmaVersion": 5,
		"sourceType": "script"
	},

  "rules": {
		"semi": 2,
		"strict": 2
	}
};
